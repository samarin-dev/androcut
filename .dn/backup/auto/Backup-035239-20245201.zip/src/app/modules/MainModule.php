<?php
namespace app\modules;

use app\forms\add;
use action\Element;
use app\forms\MainForm;
use php\io\IOException;
use localization;
use std, gui, framework, app;
use php\gui\framework\ScriptEvent; 


class MainModule extends AbstractModule
{

    /**
     * @event fileChooser.action 
     */
    function doFileChooserAction(ScriptEvent $e = null)
    {    
        $file = $this->fileChooser->file;
        $filename = $file->getName();
        fs::makeFile("scripts/$filename");
        fs::copy($file, "scripts/$filename");
    }

    /**
     * @event action 
     */
    function doAction(ScriptEvent $e = null)
    {    
        $this->PrepUI();
        $this->getUpdate();
    }

    /**
     * @event fileChooser4.action 
     */
    function doFileChooser4Action(ScriptEvent $e = null)
    {    
        $content = fs::get($this->fileChooser4->file);
        app()->form('scripteditor')->textArea->text = $content;
    }

    /**
     * @event fileChooser3.action 
     */
    function doFileChooser3Action(ScriptEvent $e = null)
    {    
        $content = app()->form('scripteditor')->textArea->text;
        fs::makeFile($this->fileChooser3->file);
        file_put_contents($this->fileChooser3->file, $content);
    }
    
    protected $process, $thread;
    
    /**
    * Starting process and getting output
    * @string Command to Execute
    */
    public function start($command)
    {   
        $this->form('MainForm')->listView->items->clear();
        $this->form('MainForm')->listView6->items->clear();
        
        $this->process = new Process(explode(' ', $command));
        $this->process = $this->process->start();
        
        $this->thread = new Thread(function(){
            $this->process->getInput()->eachLine(function($line){
                uiLater(function() use ($line) {
                    $this->addConsole($line, '#FFFFFF');
                });
            });

            $this->process->getError()->eachLine(function($line){
                uiLater(function () use ($line) {
                    $this->addConsole($line, '#FFAAAA');
                }); 
            });
            
            $exitValue = $this->process->getExitValue();
            uiLater(function () use ($exitValue) {
              
            });
        });
        
        $this->thread->start();
        
        $this->AddToLog("$command",'CMD');
    }
    
    
    /**
    * Adding Elements to listView
    * @string Line to add
    * @string Line color in HTML format (like #ffffff)
    */
    protected function addConsole($line, $color = '#FFFFFF'){

        if(str::length(str::trim($line)) == 0)return; 
        
        $line = str_replace('package:', '', $line);
        
        $item = new UXCheckbox;
        $item->autoSize = true;
        
        if (str::contains($line, 'mediatek') == true) //here starts SoC    //-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/system.png'));
            $item->css('-fx-text-fill','#e64d4d');
        }
        elseif (str::contains($line, 'mtk') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/system.png'));
            $item->css('-fx-text-fill','#e64d4d');
        }
        elseif (str::contains($line, 'sprd') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/system.png'));
            $item->css('-fx-text-fill','#e64d4d');
        }
        elseif (str::contains($line, 'spreadtrum') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/system.png'));
            $item->css('-fx-text-fill','#e64d4d');
        }
        elseif (str::contains($line, 'qualcomm') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/system.png'));
            $item->css('-fx-text-fill','#e64d4d');
        }
        elseif (str::contains($line, 'qcom') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/system.png'));
            $item->css('-fx-text-fill','#e64d4d');
        }
        elseif (str::contains($line, 'com.android') == true) //here starts GMS and Android    //-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/android-ser.png'));
            $item->css('-fx-text-fill','#b3b31a');
        }
        elseif (str::contains($line, 'com.google') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/google.png'));
            $item->css('-fx-text-fill','#b3b31a');
        }
        elseif (str::contains($line, 'transsion') == true) //here starts OEM/ODM    //-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/hios.png'));
            $item->css('-fx-text-fill','#6680e6');
        }
        elseif (str::contains($line, 'zte') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/zte-ser.png'));
            $item->css('-fx-text-fill','#6680e6');
        }
        elseif (str::contains($line, 'miui') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/miui.png'));
            $item->css('-fx-text-fill','#6680e6');
        }
        elseif (str::contains($line, 'xiaomi') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/miui.png'));
            $item->css('-fx-text-fill','#6680e6');
        }
        elseif (str::contains($line, 'mi') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/miui.png'));
            $item->css('-fx-text-fill','#6680e6');
        }
        elseif (str::contains($line, 'oneplus') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/oxygen-ser.png'));
            $item->css('-fx-text-fill','#6680e6');
        }
        elseif (str::contains($line, 'meizu') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/flyme-ser.png'));
            $item->css('-fx-text-fill','#6680e6');
        }
        elseif (str::contains($line, 'samsung') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/oneui-ser.png'));
            $item->css('-fx-text-fill','#6680e6');
        }
        elseif (str::contains($line, 'sec') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/oneui-ser.png'));
            $item->css('-fx-text-fill','#6680e6');
        }
        elseif (str::contains($line, 'lenovo') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/oneui-ser.png'));
            $item->css('-fx-text-fill','#6680e6');
        }
        elseif (str::contains($line, 'ua.') == true) //here starts third-party software    //-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/dia.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'facebook') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/facebook.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'instagram') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/instagram.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'viber') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/viber-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'telegram') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/telegram-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'spotify') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/spotify-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'discord') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/discord-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'whatsapp') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/whatsapp-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'openai') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/openai-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'microsoft') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/microsoft-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'binance') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/binance-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'valve') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/steam-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'zhiliaoapp') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/tiktok-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'netflix') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/tiktok-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'amazon') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/amazon-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'reddit') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/reddit-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'twitter') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/x-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'gallery') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/gallery-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'photo') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/gallery-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'music') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/music-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'audio') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/music-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'video') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/video-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'player') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/video-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'launcher') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/launcher-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'theme') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/launcher-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'no.') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/norwey-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'pl.') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/pl-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'us.') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/us-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'uk.') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/uk-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'ro.') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/ro-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        elseif (str::contains($line, 'cz.') == true)
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/cz-ser.png'));
            $item->css('-fx-text-fill','#80b380');
        }
        else 
        {
            $img_icon = new UXImageView(new UXImage('res://.data/img/material.png'));
            $item->css('-fx-text-fill','#80b380');
        }
                                 
        $icon = new UXHBox([$img_icon]);
        $item->text = $line;
        $item->graphic = $icon;
        $item->autoSize = TRUE;
        $item->wrapText = TRUE;
        $item->rightAnchor = 1;
        $item->leftAnchor = 1;
        $item->height = 26;
        
        $this->form('MainForm')->listView->items->add($item);
        $this->form('MainForm')->listView->scrollTo($this->listView->items->count);
        
        $item_alt = $item->text;
        $this->form('MainForm')->listView6->items->add($item_alt);
        $this->form('MainForm')->listView6->scrollTo($this->listView6->items->count);
    }
    
    /**
    * Actions With ADB
    * @string Command (action)
    */
    function ADBAction ($action)
    {   
        try 
        {
            $output = (new Process ( explode(' ', "$action")))->start()->getInput()->readFully();
        }
        catch (IOException $e) {$this->toast($e);}
        
        $fxout = new UXLabelEx;
        $fxout->rightAnchor = 1;
        $fxout->leftAnchor = 1;
        $fxout->text = $output;
        $fxout->textColor = UXColor::of('#ffff4d');
        $img_icon = new UXImageView(new UXImage('res://.data/img/device.png'));                          
        $icon = new UXHBox([$img_icon]);
        $fxout->graphic = $icon;
        
        $this->form('MainForm')->listViewAlt->items->add($fxout);
        $this->form('MainForm')->listView6->items->add($output);
        $this->form('MainForm')->listViewAlt->scrollTo($this->listViewAlt->items->count);
        $this->form('MainForm')->listView6->scrollTo($this->listView6->items->count);
        
        $this->AddToLog("$action",'CMD');
        $this->AddToLog(implode(null, "$output"),'RES');
    }
    
    /**
    * Actions With Fastboot
    * @string Command (action)
    */
    function FastbootAction($action)
    {
        try 
        {
            $output = (new Process ( explode(' ', "$action")))->start()->getInput()->readFully();
        }
        catch (IOException $e) {$this->toast($e);}
        
        $fxout = new UXLabelEx;
        $fxout->rightAnchor = 1;
        $fxout->leftAnchor = 1;
        $fxout->text = $output;
        $fxout->textColor = UXColor::of('#ffff4d');
        $img_icon = new UXImageView(new UXImage('res://.data/img/android.png'));                          
        $icon = new UXHBox([$img_icon]);
        $fxout->graphic = $icon;
        
        $this->form('MainForm')->listView3->items->add($fxout);
        $this->form('MainForm')->listView3->scrollTo($this->listView3->items->count());
        
        $this->AddToLog("$action",'CMD');
        $this->AddToLog(implode(null,"$output"),'RES');
    }
    
    /**
    * Setting Up Localization
    * @string Localization Code (en-US, uk-UA, ru-RU, etc.)
    */
    function localization($locale = 'en-US')
    {
        $this->AddToLog("Localization changed to $locale",'ACT');
        
        if ($locale == 'uk-UA')
        {
            $this->form('MainForm')->tabPane->selectFirstTab();
            $this->form('MainForm')->tabPane->selectedTab->text = 'Застосунки (Ручне)';
            $this->form('MainForm')->tabPane->selectNextTab();
            $this->form('MainForm')->tabPane->selectedTab->text = 'Fastboot (Ручне)';
            $this->form('MainForm')->tabPane->selectNextTab();
            $this->form('MainForm')->tabPane->selectedTab->text = 'Скрипти';
            $this->form('MainForm')->tabPane->selectNextTab();
            $this->form('MainForm')->tabPane->selectedTab->text = 'Консоль (Ручне)';
            $this->form('MainForm')->tabPane->selectFirstTab();
            $this->form('MainForm')->checkboxAlt->text = 'Всі';
            $this->form('MainForm')->checkbox3->text = 'Вимкнуті';
            $this->form('MainForm')->checkbox4->text = 'Увімкнуті';
            $this->form('MainForm')->checkbox5->text = 'Системні';
            $this->form('MainForm')->checkbox6->text = 'Сторонні';
            $this->form('MainForm')->spoiler->text = 'Керування пристроєм';
            $this->form('MainForm')->spoiler3->text = 'Стерти';
            $this->form('MainForm')->spoiler5->text = 'Записати';
            $this->form('MainForm')->combobox->promptText = 'Розділ...';
            $this->form('MainForm')->comboboxAlt->promptText = 'Розділ...';
            $this->form('MainForm')->combobox3->promptText = 'Пристрій...';
            $this->form('MainForm')->combobox3->text = 'Пристрій...';
            $this->form('MainForm')->editimg->promptText = 'Образ запису...';
            $this->form('MainForm')->editAlt->promptText = 'Ім`я скрипту';
            $this->form('MainForm')->edit3->promptText = 'Команда';
            $this->form('MainForm')->button7->text = 'Перезавантажити';
            $this->form('MainForm')->button9->text = 'До завантажувача';
            $this->form('MainForm')->button11->text = 'Вимкнути';
            $this->form('MainForm')->button10->text = 'Ввмк/Вимк Екран';
            $this->form('MainForm')->button20->text = 'Керування...';
            $this->form('MainForm')->button12->text = 'Стерти';
            $this->form('MainForm')->button29->text = 'ОЕМ Розблк.';
            $this->form('MainForm')->button30->text = 'Розбл. Запису';
            $this->form('MainForm')->button16->text = 'Крит. Розблк.';
            $this->form('MainForm')->button24->text = 'ОЕМ Блок.';
            $this->form('MainForm')->button26->text = 'Блок. Запису';
            $this->form('MainForm')->button18->text = 'Крит. Блок.';
            $this->form('MainForm')->button31->text = 'До EDL';
            $this->form('MainForm')->button32->text = 'Записати';
            $this->form('MainForm')->button14->text = 'Локально';
            $this->form('MainForm')->button42->text = 'Застосунки на пристрої';
            $this->form('MainForm')->button19->text = 'Виконати';
            $this->form('MainForm')->button22->text = 'Обрати';
            $this->form('MainForm')->button23->text = 'Інформація';
            $this->form('MainForm')->edit->promptText = 'Назва пакету...';
            $this->form('MainForm')->button38->text = 'Пошук';
            $this->form('MainForm')->button35->text = 'Шукати в мережі';
            $this->form('MainForm')->button46->text = 'Бездротове з`єднання';
        }
        elseif ($locale == 'ru-RU')
        {
            $this->form('MainForm')->tabPane->selectFirstTab();
            $this->form('MainForm')->tabPane->selectedTab->text = 'Приложения (Ручное)';
            $this->form('MainForm')->tabPane->selectNextTab();
            $this->form('MainForm')->tabPane->selectedTab->text = 'Fastboot (Ручное)';
            $this->form('MainForm')->tabPane->selectNextTab();
            $this->form('MainForm')->tabPane->selectedTab->text = 'Скрипты';
            $this->form('MainForm')->tabPane->selectNextTab();
            $this->form('MainForm')->tabPane->selectedTab->text = 'Консоль (Ручное)';
            $this->form('MainForm')->tabPane->selectFirstTab();
            $this->form('MainForm')->checkboxAlt->text = 'Все';
            $this->form('MainForm')->checkbox3->text = 'Отключенные';
            $this->form('MainForm')->checkbox4->text = 'Включенные';
            $this->form('MainForm')->checkbox5->text = 'Системные';
            $this->form('MainForm')->checkbox6->text = 'Сторонние';
            $this->form('MainForm')->spoiler->text = 'Управление устройством';
            $this->form('MainForm')->spoiler3->text = 'Стереть';
            $this->form('MainForm')->spoiler5->text = 'Записать';
            $this->form('MainForm')->combobox->promptText = 'Раздел...';
            $this->form('MainForm')->comboboxAlt->promptText = 'Раздел...';
            $this->form('MainForm')->combobox3->promptText = 'Устройство...';
            $this->form('MainForm')->combobox3->text = 'Устройство...';
            $this->form('MainForm')->editimg->promptText = 'Образ записи...';
            $this->form('MainForm')->editAlt->promptText = 'Имя скрипта';
            $this->form('MainForm')->edit3->promptText = 'Команда';
            $this->form('MainForm')->button7->text = 'Перезагрузить';
            $this->form('MainForm')->button9->text = 'К загрузчику';
            $this->form('MainForm')->button11->text = 'Выключить';
            $this->form('MainForm')->button10->text = 'Вкл/Выкл Экран';
            $this->form('MainForm')->button20->text = 'Управление...';
            $this->form('MainForm')->button12->text = 'Стереть';
            $this->form('MainForm')->button29->text = 'ОЕМ Разбл.';
            $this->form('MainForm')->button30->text = 'Разбл. Записи';
            $this->form('MainForm')->button16->text = 'Крит. Разблк.';
            $this->form('MainForm')->button24->text = 'ОЕМ Блок.';
            $this->form('MainForm')->button26->text = 'Блок. Записи';
            $this->form('MainForm')->button18->text = 'Крит. Блок.';
            $this->form('MainForm')->button31->text = 'Перейти к EDL';
            $this->form('MainForm')->button32->text = 'Записать';
            $this->form('MainForm')->button14->text = 'Локально';
            $this->form('MainForm')->button42->text = 'Приложения устройства';
            $this->form('MainForm')->button19->text = 'Выполнить';
            $this->form('MainForm')->button22->text = 'Выбрать';
            $this->form('MainForm')->button23->text = 'Информация';
            $this->form('MainForm')->edit->promptText = 'Имя пакета...';
            $this->form('MainForm')->button38->text = 'Поиск';
            $this->form('MainForm')->button35->text = 'Искать в сети';
            $this->form('MainForm')->button46->text = 'Беспроводное соединение';
        }
        elseif ($locale == 'en-US')
        {
            $this->form('MainForm')->tabPane->selectFirstTab();
            $this->form('MainForm')->tabPane->selectedTab->text = 'Apps (Manual)';
            $this->form('MainForm')->tabPane->selectNextTab();
            $this->form('MainForm')->tabPane->selectedTab->text = 'Fastboot (Manual)';
            $this->form('MainForm')->tabPane->selectNextTab();
            $this->form('MainForm')->tabPane->selectedTab->text = 'Scripts';
            $this->form('MainForm')->tabPane->selectNextTab();
            $this->form('MainForm')->tabPane->selectedTab->text = 'Console (Manual)';
            $this->form('MainForm')->tabPane->selectFirstTab();
            $this->form('MainForm')->checkboxAlt->text = 'All';
            $this->form('MainForm')->checkbox3->text = 'Disabled';
            $this->form('MainForm')->checkbox4->text = 'Enabled';
            $this->form('MainForm')->checkbox5->text = 'System';
            $this->form('MainForm')->checkbox6->text = 'Third-party';
            $this->form('MainForm')->spoiler->text = 'Device controls';
            $this->form('MainForm')->spoiler3->text = 'Wipe';
            $this->form('MainForm')->spoiler5->text = 'Flash';
            $this->form('MainForm')->combobox->promptText = 'Partition...';
            $this->form('MainForm')->comboboxAlt->promptText = 'Partition...';
            $this->form('MainForm')->combobox3->promptText = 'Device...';
            $this->form('MainForm')->combobox3->text = 'Device...';
            $this->form('MainForm')->editimg->promptText = 'Flashing image...';
            $this->form('MainForm')->editAlt->promptText = 'Script name';
            $this->form('MainForm')->edit3->promptText = 'Command';
            $this->form('MainForm')->button7->text = 'Reboot';
            $this->form('MainForm')->button9->text = 'Reboot to B-loader';
            $this->form('MainForm')->button11->text = 'Shutdown';
            $this->form('MainForm')->button10->text = 'On/Off Screen';
            $this->form('MainForm')->button20->text = 'Control...';
            $this->form('MainForm')->button12->text = 'Wipe';
            $this->form('MainForm')->button29->text = 'ОЕМ Unlock';
            $this->form('MainForm')->button30->text = 'Flash Unlock';
            $this->form('MainForm')->button16->text = 'Critical Unlock';
            $this->form('MainForm')->button24->text = 'ОЕМ Lock';
            $this->form('MainForm')->button26->text = 'Flash Lock';
            $this->form('MainForm')->button18->text = 'Critical Lock';
            $this->form('MainForm')->button31->text = 'Move to EDL';
            $this->form('MainForm')->button32->text = 'Flash';
            $this->form('MainForm')->button14->text = 'Local';
            $this->form('MainForm')->button42->text = 'Packages on device';
            $this->form('MainForm')->button19->text = 'Execute';
            $this->form('MainForm')->button22->text = 'Select';
            $this->form('MainForm')->button23->text = 'Get info';
            $this->form('MainForm')->edit->promptText = 'Package name...';
            $this->form('MainForm')->button38->text = 'Search';
            $this->form('MainForm')->button35->text = 'Search on the web';
            $this->form('MainForm')->button46->text = 'Wireless connect';
        }
    }
    
    /**
    * Getting Information About Updates
    */
    function getUpdate()
    {
        $current = '2024.05';
        
        $this->AddToLog("Androcut $current", 'INF');
        
        try 
        {
            $version = str::trim(file_get_contents('https://samarin-dev.github.io/androcut/VERSION.md'));
        }
        catch (Error $e) {$this->toast($e);}
        
        try 
        {
            $changelog = fs::get('https://samarin-dev.github.io/androcut/CHANGELOG.md');
        }
        catch (Error $e) {$this->toast($e);}
        
        if ($version != $current)
        {
            app()->showForm('update');
            app()->form('update')->labelAlt->text = "Current ver.: $current";
            app()->form('update')->label3->text = "New ver.: $version";
            app()->form('update')->textArea->text = $changelog;
            $this->AddToLog("A new version found: $version", 'INF');
        }
    }
    
    /**
    * AI Assistant Backend
    */
    function AICompare($input)
    {
        $db = $this->ini->sections();
        $needle = $this->listView->selectedItem->text;
        
        $this->label17->text = "Name: N/A";
        $this->label18->text = "Type: N/A";
        $this->label19->text = "Rating: N/A";
        $this->label20->text = "Reccomends: N/A";
        
        foreach ($db as $part)
        {
            if (str::contains($part, $needle) == true)
            {
                $info = $this->ini->section($part);
                $this->label17->text = "Name: $info[0]";
                $this->label18->text = "Type: $info[1]";
                $this->label19->text = "Rating: $info[2]";
                $this->label20->text = "Reccomends: $info[3]";
            }
        }
    }
    
    /**
    * Witing All Actions To Log File
    */    
    function AddToLog ($logstring, $logcode)
    {
        $time = Time::now();
        
        if ($logcode == 'ERR')
        {
            file_put_contents('log.md5', "$time ::: ERROR ::: $logstring \r\n", FILE_APPEND);
        }
        elseif ($logcode == 'CMD')
        {
            file_put_contents('log.md5', "$time > $logstring \r\n", FILE_APPEND);
        }
        elseif ($logcode == 'RES')
        {
            file_put_contents('log.md5', "$time | $logstring \r\n", FILE_APPEND);
        }
        elseif ($logcode == 'ACT')
        {
            file_put_contents('log.md5', "$time * $logstring \r\n", FILE_APPEND);
        }
        elseif ($logcode == 'INF')
        {
            file_put_contents('log.md5', ".:: $logstring ::.\r\n", FILE_APPEND);
        }
    }
    
    /**
    * Preparing User Interface Before Application Starts
    */
    function PrepUI ()
    {
        //Getting Values
        $langid = $this->cfg->get('LocaleID', 'GLOBAL');
        $aimode = $this->cfg->get('AIMode', 'GLOBAL');
        $nobg = $this->cfg->get('NoBg', 'GLOBAL');
        $fsst = $this->cfg->get('StartFullScreen', 'GLOBAL');
        
        //Preparing Language Settings 
        if ($langid == 0)
        {
            $this->form('MainForm')->localization('en-US');
        }
        elseif ($langid == 1)
        {
            $this->form('MainForm')->localization('uk-UA');
        }
        elseif ($langid == 2)
        {
            $this->form('MainForm')->localization('ru-RU');
        }
        else 
        {
            $this->form('MainForm')->localization('en-US');
            $this->form('MainForm')->AddToLog('Localization switch error', 'ERR');
        }
        
        //Background
        if ($nobg == 1)
        {
            $this->form('MainForm')->image->hide();
        }
        else 
        {
            $this->form('MainForm')->image->show();
        }
        
        if ($fsst == 1)
        {
            $this->form('MainForm')->fullScreen = true;
        }
        else 
        {
            $this->form('MainForm')->fullScreen = false;
        }
    }

}
