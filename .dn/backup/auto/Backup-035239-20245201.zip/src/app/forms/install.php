<?php
namespace app\forms;

use php\lib\str;
use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 


class install extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {
        $this->progressIndicator->show();
        $path = $this->apkoutpath->text;
        $path = htmlspecialchars_decode("&quot;$path&quot;");
        
        if ($this->checkbox->selected == false)
        {
            $action = "adb install --no-streaming $path";
            app()->form('MainForm')->ADBAction($action);
        }
        else 
        {
            $devices = app()->form('MainForm')->combobox3->items->toArray();
            
            foreach ($devices as $device)
            {
                $device = explode(' ', $device);
                $device= str::trim($deviceid[0]);
                $action = "adb -s $device install --no-streaming $path";
                app()->form('MainForm')->ADBAction($action);
            }
        }
        
        $this->progressIndicator->hide();
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {
        $this->progressIndicator->show();
    }




}
