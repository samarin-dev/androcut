<?php
namespace app\forms;

use php\gui\layout\UXHBox;
use php\gui\UXImage;
use php\gui\UXImageView;
use php\gui\paint\UXColor;
use php\gui\UXLabelEx;
use php\lib\str;
use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 
use php\lib\fs;

class settings extends AbstractForm
{
    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {    
        $logfile = explode("\n", fs::get('log.md5'));
        
        $this->listView->items->clear();
        
        foreach ($logfile as $logstr)
        {
            /*$rval[0] = "\r";
            $rval[1] = "\n";
            $logstr = str::replace("\n", null, $logstr);*/
            
            $fxout = new UXLabelEx;
            $fxout->rightAnchor = 1;
            $fxout->leftAnchor = 1;
            $fxout->text = $logstr;
            
            if (str::contains($logstr, ':::'))
            {
                $fxout->css('-fx-text-fill','#e64d4d');
                $img_icon = new UXImageView(new UXImage('res://.data/img/break.png'));                          
                $icon = new UXHBox([$img_icon]);
                $fxout->graphic = $icon;
            }
            elseif (str::contains($logstr, '>'))
            {
                $fxout->css('-fx-text-fill','#b3b31a');
                $img_icon = new UXImageView(new UXImage('res://.data/img/terminal.png'));                          
                $icon = new UXHBox([$img_icon]);
                $fxout->graphic = $icon;
            }
            elseif (str::contains($logstr, '|'))
            {
                $fxout->css('-fx-text-fill','#80b380');
                $img_icon = new UXImageView(new UXImage('res://.data/img/android-ser.png'));                          
                $icon = new UXHBox([$img_icon]);
                $fxout->graphic = $icon;
            }
            elseif (str::contains($logstr, '*'))
            {
                $fxout->css('-fx-text-fill','#cccccc');
                $img_icon = new UXImageView(new UXImage('res://.data/img/click.png'));                          
                $icon = new UXHBox([$img_icon]);
                $fxout->graphic = $icon;
            }
            elseif (str::contains($logstr, '.::'))
            {
                $fxout->css('-fx-text-fill','#6680e6');
                $img_icon = new UXImageView(new UXImage('res://.data/img/info.png'));                          
                $icon = new UXHBox([$img_icon]);
                $fxout->graphic = $icon;
            }
            
            $this->listView->items->add($fxout);
            $this->listView->scrollTo($this->listView->items->count());
        }
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        if ($this->checkbox->selected == true)
        {
            $bg = 1;
        }
        else 
        {
            $bg = 0;
        }
        
        if ($this->checkboxAlt->selected == true)
        {
            $fullscrn = 1;
        }
        else 
        {
            $fullscrn = 0;
        }
        
        if ($this->checkbox3->selected == true)
        {
            $ai = 1;
        }
        else 
        {
            $ai = 0;
        }
        
        $langid = $this->combobox4->selectedIndex;
        
        $this->cfg->set('LocaleID', $langid, 'GLOBAL');
        $this->cfg->set('StartFullScreen', $fullscrn, 'GLOBAL');
        $this->cfg->set('NoBg', $bg, 'GLOBAL');
        
        $this->PrepUI();
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        app()->hideForm('settings');
    }



}
