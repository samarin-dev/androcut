<?php
namespace app\forms;

use php\gui\layout\UXHBox;
use php\gui\UXImage;
use php\gui\UXImageView;
use php\gui\paint\UXColor;
use php\gui\UXLabelEx;
use php\lib\str;
use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 
use php\lib\fs;

class settings extends AbstractForm
{

    /**
     * @event combobox4.action 
     */
    function doCombobox4Action(UXEvent $e = null)
    {    
        if ($this->combobox4->selectedIndex == 0)
        {
            $this->form('MainForm')->localization('en-US');
        }
        elseif ($this->combobox4->selectedIndex == 1)
        {
            $this->form('MainForm')->localization('uk-UA');
        }
        elseif ($this->combobox4->selectedIndex == 2)
        {
            $this->form('MainForm')->localization('ru-RU');
        }
        else 
        {
            $this->form('MainForm')->localization('en-US');
            $this->form('MainForm')->AddToLog('Localization switch error', 'ERR');
        }
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {    
        $logfile = explode("\n", fs::get('log.md5'));
        
        $this->listView->items->clear();
        
        foreach ($logfile as $logstr)
        {
            /*$rval[0] = "\r";
            $rval[1] = "\n";
            $logstr = str::replace("\n", null, $logstr);*/
            
            $fxout = new UXLabelEx;
            $fxout->rightAnchor = 1;
            $fxout->leftAnchor = 1;
            $fxout->text = $logstr;
            
            if (str::contains($logstr, ':::'))
            {
                $fxout->css('-fx-text-fill','#e64d4d');
                $img_icon = new UXImageView(new UXImage('res://.data/img/break.png'));                          
                $icon = new UXHBox([$img_icon]);
                $fxout->graphic = $icon;
            }
            elseif (str::contains($logstr, '>'))
            {
                $fxout->css('-fx-text-fill','#b3b31a');
                $img_icon = new UXImageView(new UXImage('res://.data/img/terminal.png'));                          
                $icon = new UXHBox([$img_icon]);
                $fxout->graphic = $icon;
            }
            elseif (str::contains($logstr, '|'))
            {
                $fxout->css('-fx-text-fill','#80b380');
                $img_icon = new UXImageView(new UXImage('res://.data/img/android-ser.png'));                          
                $icon = new UXHBox([$img_icon]);
                $fxout->graphic = $icon;
            }
            elseif (str::contains($logstr, '*'))
            {
                $fxout->css('-fx-text-fill','#cccccc');
                $img_icon = new UXImageView(new UXImage('res://.data/img/click.png'));                          
                $icon = new UXHBox([$img_icon]);
                $fxout->graphic = $icon;
            }
            elseif (str::contains($logstr, '.::'))
            {
                $fxout->css('-fx-text-fill','#6680e6');
                $img_icon = new UXImageView(new UXImage('res://.data/img/info.png'));                          
                $icon = new UXHBox([$img_icon]);
                $fxout->graphic = $icon;
            }
            
            $this->listView->items->add($fxout);
            $this->listView->scrollTo($this->listView->items->count());
        }
    }



}
